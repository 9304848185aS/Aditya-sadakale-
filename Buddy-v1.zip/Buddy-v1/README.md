# Buddy v1 — Android आवाज़ सहायक

बोलकर अलार्म, टाइमर और ऐप खोलने वाला पहला वर्ज़न। कोई Claude/AI API नहीं, पूरी तरह फ़ोन पर चलता है।

## APK बनाने के दो तरीके

### तरीका 1: GitHub Actions (Android Studio नहीं चाहिए)
1. github.com पर नया repository बनाओ।
2. इस ZIP की सारी फ़ाइलें (`.github` फ़ोल्डर समेत) उसमें अपलोड करो।
3. Actions टैब खुलेगा, "Build APK" अपने आप चलेगा (लगभग 5 मिनट)।
4. पूरा होने पर रन खोलो, नीचे Artifacts में `buddy-apk` डाउनलोड करो, उसमें `app-debug.apk` है।
5. APK फ़ोन में डालकर इंस्टॉल करो (अनजान सोर्स की इजाज़त देनी होगी)।

### तरीका 2: Android Studio
1. Android Studio (Koala या नया) खोलो: File → Open → `Buddy-v1` फ़ोल्डर चुनो।
2. Gradle sync पूरा होने दो (पहली बार इंटरनेट चाहिए)।
3. फ़ोन USB से जोड़ो (USB debugging चालू) या emulator चलाओ।
4. Run (हरा तीर) दबाओ। या Build → Build APK(s) से APK बनाओ: `app/build/outputs/apk/debug/app-debug.apk`

## इस्तेमाल
ऐप खोलो, "बोलिए" दबाओ और कहो:
- "सुबह 7 बजे का अलार्म लगा दो"
- "5 मिनट का टाइमर लगा दो"
- "व्हाट्सऐप खोलो"
- "रुक जा"

## तकनीकी जानकारी
- भाषा: Kotlin 1.9.24, AGP 8.5.2, Gradle 8.7, Java 17
- पैकेज: `com.example.buddy`, minSdk 26, targetSdk 34
- ज़रूरी अनुमति: माइक्रोफ़ोन (RECORD_AUDIO)

## ध्यान दें
यह पहला प्रोटोटाइप है। कमांड समझने वाला हिस्सा जाँचा गया है, पर पूरा Gradle बिल्ड अभी किसी असली मशीन पर नहीं चला है, और APK इस ZIP में शामिल नहीं है। बिल्ड में error आए तो उसका टेक्स्ट Claude को भेज दो।
